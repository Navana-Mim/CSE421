import socket

server_port = 8080
format = "utf-8"
buffer_for_message_lenght = 16

#Create the server's address
hostname = socket.gethostname()
host_ip = socket.gethostbyname(hostname)

addr = (host_ip, server_port)

#Creating the socket for the client
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(addr)

def message_to_be_sent(message): #original mesage is "Hi"
    msg = message.encode(format)

    msg_length = str(len(message)) #length size asbe 2
    msg_length = msg_length.encode(format)

    padding = b" " *(buffer_for_message_lenght - len(msg_length))  #space add korlam. padding dea add kora hoye

    msg_length = msg_length + padding

    client.send(msg_length)
    client.send(msg)

    print(client.recv(2048).decode(format))


#message_to_be_sent("Hi")
#message_to_be_sent("Disconnect") 
while True:
    user_input = input("Enter:")
    message_to_be_sent(user_input)
    if user_input == "Disconnect":
        break
#message_to_be_sent(f"Hostname: {hostname} and IP: {host_ip}")
#message_to_be_sent(f"Disconnect")